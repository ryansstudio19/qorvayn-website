---
name: Obsidian Kinetic
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393f'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e1e9'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e3e1e9'
  inverse-on-surface: '#2f3036'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#a4c9ff'
  on-tertiary: '#00315d'
  tertiary-container: '#4c93e7'
  on-tertiary-container: '#002a51'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#d4e3ff'
  tertiary-fixed-dim: '#a4c9ff'
  on-tertiary-fixed: '#001c39'
  on-tertiary-fixed-variant: '#004883'
  background: '#121318'
  on-background: '#e3e1e9'
  surface-variant: '#34343a'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 4.5rem
    fontWeight: '600'
    lineHeight: '1.05'
    letterSpacing: -0.04em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 2.75rem
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 2.5rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 1.875rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 1.125rem
    fontWeight: '500'
    lineHeight: '1.35'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: '1.55'
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-lg:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system delivers a premier, high-fidelity dark-mode experience tailored for high-performance computing, advanced data architectures, and frontier technology interfaces. The atmosphere is nocturnal, precise, and quiet—evoking the focus of an aerospace operations center or an elite developer terminal rather than a neon-saturated gaming dashboard. 

The aesthetic synthesizes **Minimalism**, **Glassmorphism**, and architectural **Bento Grid** composition:
- **Foundational Void:** Immense depth anchored by obsidian and abyssal slate surfaces, giving every element high optical breathing room.
- **Architectural Lamination:** Multi-layered translucent planes suspended with ultra-fine 1px border gradients, establishing structural order without visual heaviness.
- **Electric Precision:** Concentrated bioluminescent blue accents and focused cyan micro-glows serve solely as navigational indicators, interactive beacons, and operational status signs.
- **Tone & Demeanor:** Sophisticated, deliberate, mission-critical, and impeccably calibrated. It feels forward-looking yet grounded in institutional stability.

## Colors

The palette operates under a strict luminance budget designed specifically for dark environments. Dark tones dominate 90% of the canvas to reduce eye fatigue and command attention toward active interfaces.

### Core Swatches
- **Canvas Base (`#090A0F`):** Deep obsidian void. The baseline canvas for all top-level viewports.
- **Surface Elevation 1 (`#0E1118`):** Deep abyssal slate used for major section wrappers and foundational bento tiles.
- **Surface Elevation 2 (`#141923`):** Raised interactive containers, elevated cards, and menu layers.
- **Primary Accent (`#3B82F6`):** Electric blue for primary interactive triggers, active tabs, and primary action affordances.
- **Secondary Accent (`#06B6D4`):** Focused cyan used sparingly for data telemetry, metric differentials, and micro-illumination highlights.
- **Tertiary Accent (`#60A5FA`):** Soft luminous blue for text links, hovered state perimeters, and active icon strokes.

### Application Rules
1. **Contrast Compliance:** Text on pure canvas or glass surfaces must default to `#F8FAFC` (high-emphasis, 95% opacity) or `#94A3B8` (medium-emphasis, 65% opacity). Avoid mid-gray body copy that falls below WCAG AAA on `#090A0F`.
2. **Illumination Budget:** Glowing halos and cyan highlights must never occupy large surface fills; they are strictly reserved for 1px perimeter gradients, radial cursor-followers, and indicator pings.

## Typography

The typographic hierarchy bridges experimental modernism with technical authority. 

- **Display & Headlines (Space Grotesk):** Provides structured geometric personality. Tight negative tracking (-0.02em to -0.04em) prevents the letterforms from drifting, yielding a compact, architectural presence at scale.
- **Body & Prose (Inter):** Highly legible, neutral workhorse. It balances the technological flair of Space Grotesk with clarity across continuous reading formats, data documentation, and dense parameter tables.
- **Metadata & Data Labels (JetBrains Mono):** Monospaced precision for technical badges, tags, code readouts, timestamps, and interface metrics. Uppercase applications must include expanded letter-spacing (`0.05em` to `0.08em`) to guarantee readability at micro scales.

## Layout & Spacing

The layout model is anchored by a structured 12-column Bento Grid on desktop, collapsing to 6 columns on tablet, and a single vertical flow on mobile viewports.

### Grid Rhythm & Layout Principles
- **Desktop (1200px+):** 12 columns with a fixed `1.5rem` gutter and `3rem` boundary margin. Max-width boundary for content canvases is constrained to `1440px`.
- **Tablet (768px – 1199px):** 6-column modular grid with `1.25rem` gutters and `2rem` margins. Bento cards span 3 or 6 columns.
- **Mobile (Below 768px):** 1-column stack. Bento cards span full width, dropping secondary preview panes when vertical height exceeds the device viewport.
- **Spatial Tension:** Generous spacing separates unrelated feature groupings (`space-xl`), whereas internal component padding remains compact (`space-md` to `space-lg`), creating sharp, localized modules within a vast ambient framework.

## Elevation & Depth

This system avoids traditional soft dropped shadows that mimic daylight sources. Instead, depth is achieved through an optical model of light transmission, luminous refraction, and progressive obsidian stacking.

### Surface Tiers
1. **Base Floor (Z0):** `#090A0F`, 100% opaque canvas.
2. **Flat Ground (Z1):** `#0E1118` with subtle 1px border of `rgba(255, 255, 255, 0.06)`.
3. **Glassmorphic Paneling (Z2):** Background fill of `rgba(14, 17, 24, 0.70)`, combined with a `backdrop-filter: blur(16px)` and a directional border gradient that simulates an overhead rim light: top edge `rgba(255, 255, 255, 0.14)`, shifting to bottom edge `rgba(255, 255, 255, 0.02)`.
4. **Floating Modals / Flyouts (Z3):** Background fill of `rgba(20, 25, 35, 0.85)` with `backdrop-filter: blur(24px)`. Augmented with a perimeter shadow: `0 20px 40px -15px rgba(0, 0, 0, 0.8)` plus an internal cyan-tinted highlight reflection: `0 0 1px 1px rgba(6, 182, 212, 0.25)`.

### Cyan Glow Accents
Active elements utilize radial atmospheric blurs. An active state emits a soft backlight glow using `box-shadow: 0 0 24px -4px rgba(59, 130, 246, 0.35)`. Glows should never bleed beyond a 32px spread, maintaining surgical containment.

## Shapes

The design system employs a refined geometric contour model (`roundedness: 2`):
- **Micro UI Elements (Badges, Buttons, Inputs):** `0.5rem` (8px) radius. Retains a crisp, modern form factor without aggressive rounding.
- **Standard Cards & Bento Panels:** `1rem` (16px) radius (`rounded-lg`). Creates uniform rhythm across nested grids.
- **Overlay Panels & Modals:** `1.5rem` (24px) radius (`rounded-xl`). Softens large structural viewports.
- **Pill Exceptions:** Pure pill radii are exclusively permitted for standalone technical status badges, operational indicators, and category filter chips. Form fields, structural cards, and primary buttons must retain geometric corners (`0.5rem`).

## Components

### Buttons
- **Primary:** Background of solid `#3B82F6` with text in `#FFFFFF` (Font: Space Grotesk, 500 weight). Hover shifts background to `#2563EB` paired with an ambient cyan flare (`box-shadow: 0 0 16px rgba(6, 182, 212, 0.4)`).
- **Secondary (Glass):** Background of `rgba(255, 255, 255, 0.04)` with an ultra-fine 1px border of `rgba(255, 255, 255, 0.12)`. Text in `#F8FAFC`. On hover, the border illuminates to `rgba(96, 165, 250, 0.45)` with background adjusting to `rgba(255, 255, 255, 0.08)`.
- **Ghost:** Borderless, text in `#94A3B8`. Hover changes text to `#60A5FA` with background fill of `rgba(59, 130, 246, 0.08)`.

### Bento Cards & Panels
- **Structure:** Constructed on Z2 elevation using 16px corner radii, `backdrop-filter: blur(16px)`, and 1px border gradients.
- **Header Structure:** Title set in `headline-sm` (Space Grotesk), accompanied by an optional right-aligned status chip set in `label-sm` (JetBrains Mono).
- **Hover Micro-interaction:** Hover triggers a localized radial gradient that tracks the cursor along the border perimeter (`border-image`), subtly illuminating the internal contents.

### Input Fields
- **Container:** Background of `rgba(9, 10, 15, 0.85)` with a 1px border of `rgba(255, 255, 255, 0.1)`. Radius of `0.5rem`.
- **Typography:** Placeholder text set in `body-md` with `#475569`. Active input text in `#F8FAFC`.
- **Focus State:** Border transitions instantaneously to `#3B82F6` backed by an inner glow: `box-shadow: 0 0 0 1px #3B82F6, 0 0 12px rgba(59, 130, 246, 0.25)`. Outline is set to none.

### Chips & Telemetry Badges
- **Specification:** Height of 24px, padding 0 8px, border-radius of 9999px (Pill). 
- **Typography:** `label-sm` (JetBrains Mono, uppercase).
- **Variant - Operational:** Background `rgba(6, 182, 212, 0.1)`, text `#06B6D4`, border `1px solid rgba(6, 182, 212, 0.3)`. Includes a pulsating 4px `#06B6D4` dot on the leading side.

### Checkboxes & Radio Controls
- **Geometry:** Checkboxes use `0.25rem` radius; radios use pure circles. Dimensions are strictly 18x18px.
- **Unchecked:** Border of 1px `rgba(255, 255, 255, 0.2)`, background `rgba(14, 17, 24, 0.6)`.
- **Checked:** Background `#3B82F6` displaying a white checkmark or inner dot, surrounded by a 1px glow ring of `rgba(6, 182, 212, 0.5)`.

### Lists & Data Rows
- **Treatment:** Zero dividing horizontal lines. Separation is maintained through row-level hover fills (`rgba(255, 255, 255, 0.03)`) and alternate vertical alignment padding (`space-sm` top/bottom).
- **Data Columns:** Numerical and statistical values must use `JetBrains Mono` right-aligned for vertical alignment precision.